# Themenliste: Erste 15 Blogartikel (Coaching – Selbstliebe & Selbstwertgefühl für Frauen)

Aufgebaut wie ein Trichter: erst Themen mit hohem emotionalem Suchdruck 
(Menschen suchen JETZT Orientierung), dann Grundlagen-/Wissensthemen, 
dann vertiefende Artikel, die Nähe zu dir als Coach aufbauen und zum 
Erstgespräch überleiten.

---

## Phase 1: Akuter emotionaler Suchdruck (zuerst schreiben)

1. **Warum du dich nach einer Trennung wertlos fühlst – und was jetzt wirklich hilft**
   - Intention: akute emotionale Krise, hohe Dringlichkeit
   - Long-Tail: "nach Trennung wertlos fühlen was tun"

2. **Selbstwertgefühl stärken nach einer Trennung: Die ersten Schritte**
   - Intention: konkrete Handlungsschritte gesucht
   - Direkt beantwortbar im ersten Absatz (gut für GEO)

3. **Warum ziehe ich immer wieder die falschen Partner an? (Bindungsmuster verstehen)**
   - Intention: sehr verbreitete, emotional aufgeladene Suchanfrage
   - Hohe Teilbarkeit in sozialen Netzwerken

4. **Bin ich zu anspruchsvoll oder einfach nur klar in meinen Werten?**
   - Intention: Selbstzweifel adressieren, sehr persönliche Suchintention

5. **Einsamkeit nach der Trennung: Warum sie normal ist und wie du sie nicht bekämpfen musst**
   - Intention: Trost + neue Perspektive, emotionale Bindung an die Seite

## Phase 2: Grundlagenwissen zu Selbstliebe & Selbstwert

6. **Was ist Selbstliebe eigentlich wirklich? (Und was sie NICHT ist)**
   - Intention: Grundbegriff klären, Missverständnisse ausräumen ("Selbstliebe = Egoismus")
   - Sehr gut für GEO als Definitions-Artikel

7. **Selbstwertgefühl vs. Selbstvertrauen vs. Selbstbewusstsein: Die Unterschiede**
   - Intention: Begriffsverwirrung auflösen, hohes Suchvolumen

8. **5 Anzeichen für ein geringes Selbstwertgefühl, die viele übersehen**
   - Intention: Selbsterkenntnis/Selbsttest-Charakter, hohe Verweildauer

9. **Warum "Liebe dich einfach selbst" der schlechteste Rat ist, den du bekommen kannst**
   - Intention: Kontrastierender Standpunkt, positioniert dich als differenzierte Stimme
   - Guter Artikel für Markenprofil/Abgrenzung von oberflächlichen Ratgebern

10. **Innere Kritikerin: Woher sie kommt und wie du ihr nicht mehr glaubst**
    - Intention: konkretes psychologisches Konzept, gut greifbar für Leserinnen

## Phase 3: Vertiefung, Nähe & Übergang zum Coaching

11. **3 einfache Übungen für mehr Selbstwertgefühl im Alltag**
    - Intention: sofort umsetzbarer Mehrwert, gut teilbar
    - Perfekt für Mini-Übungen aus dem Prompt-Template

12. **Warum du dein Selbstwertgefühl nicht allein an deiner Beziehung festmachen solltest**
    - Intention: Verbindung zu Beziehungsthemen, breite Zielgruppen-Relevanz

13. **Wie ein Coaching-Prozess bei Selbstwertthemen wirklich abläuft (Einblick)**
    - Intention: Ängste/Unklarheit vor Coaching abbauen, direkte Brücke zu deinem Angebot
    - Guter Ort für sanften CTA zum Erstgespräch

14. **Erfahrungsbericht: Wie eine Klientin nach einer Trennung wieder zu sich fand**
    - Intention: emotionale Identifikation, Social Proof
    - WICHTIG: anonymisieren bzw. nur mit expliziter Zustimmung der Klientin veröffentlichen

15. **Selbstfürsorge ist kein Luxus: Warum du sie dir erlauben darfst**
    - Intention: Grundhaltung vermitteln, gute Newsletter-Anknüpfung, breite Teilbarkeit

---

## Hinweise zur Umsetzung

- **Artikel 1-5 zuerst**, weil hier die emotionale Dringlichkeit am höchsten ist – 
  das bringt früh Traffic von Frauen, die aktiv nach Orientierung suchen.
- Jedes Thema kannst du 1:1 als "THEMA:"-Wert ins Coaching-Prompt-Template einsetzen.
- Bei Artikel 14 (Erfahrungsbericht): nur mit ausdrücklicher Einwilligung der 
  Klientin veröffentlichen, im Zweifel lieber ein fiktives, aber realistisches 
  Kompositum aus mehreren anonymisierten Fällen verwenden.
- Für maximale GEO-Wirkung: Jedes Thema hat idealerweise 3-5 "echte" Fragen, 
  wie sie jemand in ChatGPT eintippen würde – gehören in die FAQ-Sektion.

#!/usr/bin/env node
/**
 * generate-articles-coaching.js
 *
 * Generiert aus topics-coaching.json automatisch SEO/GEO-optimierte
 * Blogartikel als statische HTML-Dateien für deine Coaching-Website
 * (Selbstliebe & Selbstwertgefühl für Frauen ab 30).
 *
 * VORAUSSETZUNGEN:
 *   1. Node.js 18+ (bringt fetch bereits mit)
 *   2. Umgebungsvariable ANTHROPIC_API_KEY gesetzt
 *      (API-Key unter https://console.anthropic.com)
 *
 * NUTZUNG:
 *   export ANTHROPIC_API_KEY="dein-key"
 *   node generate-articles-coaching.js
 *
 *   Optional: nur ein einzelnes Thema generieren
 *   node generate-articles-coaching.js --slug wertlos-nach-trennung
 *
 * OUTPUT:
 *   ./output/<slug>.html
 *
 * WICHTIG:
 *   Jeder generierte Artikel ist ein ENTWURF.
 *   - Bei psychologischen Themen: keine unbelegten Heilsversprechen stehen lassen
 *   - Beim Erfahrungsbericht-Artikel: nur mit Einwilligung der Klientin
 *     veröffentlichen, sonst anonymisieren/fiktionalisieren
 */

const fs = require("fs");
const path = require("path");

const API_KEY = process.env.ANTHROPIC_API_KEY;
if (!API_KEY) {
  console.error("Fehler: Umgebungsvariable ANTHROPIC_API_KEY ist nicht gesetzt.");
  console.error('Setze sie z.B. mit: export ANTHROPIC_API_KEY="dein-key"');
  process.exit(1);
}

const TOPICS_FILE = path.join(__dirname, "topics-coaching.json");
const OUTPUT_DIR = path.join(__dirname, "output-coaching");
const MODEL = "claude-sonnet-4-6";

const SITE_NAME = "[DEIN COACHING-BRAND-NAME]"; // <-- anpassen
const SITE_URL = "https://[DEINE-DOMAIN].de"; // <-- anpassen
const CTA_TEXT =
  "Wenn dich das Thema anspricht und du tiefer einsteigen möchtest: " +
  "Ich begleite Frauen dabei, ihr Selbstwertgefühl und ihre Selbstliebe " +
  "Schritt für Schritt wieder aufzubauen. " +
  '<a href="[LINK ZU DEINEM ERSTGESPRÄCH]">Vereinbare hier ein unverbindliches Erstgespräch</a>.';

// --- Prompt-Template (Basis: das mit dir erarbeitete Coaching-Template) ---
function buildPrompt(topic) {
  return `Du bist eine erfahrene Content-Strategin für SEO- und GEO-optimierte
(Generative Engine Optimization für ChatGPT, Perplexity, Gemini, Google AI Overviews)
Blogartikel im Bereich Coaching für Frauen.

KONTEXT DER SEITE:
Die Seite bietet Coaching für Frauen ab 30, mit Schwerpunkt auf Selbstliebe,
Selbstwertgefühl und persönlicher Weiterentwicklung – u.a. auch für Frauen,
die nach einer Trennung oder Lebenskrise wieder zu sich finden wollen.

THEMA: ${topic.thema}
ZIELGRUPPE: Frauen ab 30, die an ihrem Selbstwertgefühl arbeiten wollen
  (Auslöser oft: Trennung, berufliche Umbrüche, Lebensveränderungen)
HAUPTKEYWORD: ${topic.hauptkeyword}
VERWANDTE BEGRIFFE/ENTITÄTEN: ${topic.verwandte_begriffe}
ZIEL DES ARTIKELS: Vertrauen aufbauen, Expertise zeigen, zum Coaching-Erstgespräch führen
TONALITÄT: warm, empathisch, direkt – keine Floskeln, auf Augenhöhe, ermutigend statt belehrend
LÄNGE: ${topic.laenge}

STRUKTUR:
1. Direkter, emotional ansprechender Einstieg: Erster Absatz spricht die Leserin
   direkt an und beantwortet die Kernfrage in 2-3 Sätzen (eigenständig zitierfähig).
2. Klare H2/H3-Struktur, Überschriften als Fragen formuliert, wie Frauen sie
   wirklich googeln/in ChatGPT eingeben würden.
3. Unter jeder Überschrift: erst klare, einordnende Antwort, dann Vertiefung
   mit konkreten Impulsen/Übungen.
4. Mindestens 1-2 konkrete, sofort umsetzbare Mini-Übungen oder Reflexionsfragen.
5. FAQ-Sektion am Ende mit 5-6 realistischen Fragen der Zielgruppe.
6. TL;DR-Box mit den 3-4 wichtigsten Punkten am Artikelanfang.

CONTENT-QUALITÄT:
- Eigene Coaching-Erfahrung/Perspektive einfließen lassen (anonymisierter Praxisbezug)
- Psychologisch fundierte, aber allgemeinverständliche Begriffe
- Keine unbelegten "Wissenschaft sagt"-Behauptungen; vorsichtig formulieren
- Ehrlich, nicht überversprechend: Selbstwertarbeit ist ein Prozess,
  keine Sieben-Tage-Lösung

SEO-BASIS:
- Hauptkeyword natürlich in H1, erstem Absatz und mind. einer H2
- Semantisch verwandte Begriffe verteilen (kein Keyword-Stuffing)
- Meta-Title (max. 60 Zeichen) und Meta-Description (max. 155 Zeichen) vorschlagen

GEO-SPEZIFISCH:
- Absätze so formulieren, dass sie auch isoliert von einer KI zitiert werden können
- Konsistente Terminologie
- Am Ende Vorschlag für strukturierte Daten (Schema.org: Article, FAQPage)

WICHTIG FÜR DIE AUSGABE:
Antworte AUSSCHLIESSLICH mit einem JSON-Objekt (kein Markdown, kein Codeblock-Fence),
mit exakt diesen Feldern:
{
  "meta_title": "...",
  "meta_description": "...",
  "h1": "...",
  "body_html": "<p>...</p><h2>...</h2>...",
  "faq": [{"frage": "...", "antwort": "..."}, ...],
  "beispiel_prompts": ["...", "..."],
  "social_media_titel": "..."
}

body_html soll bereits valides, semantisches HTML sein (p, h2, h3, ul, li etc.),
OHNE die FAQ-Sektion (die wird separat aus dem "faq"-Feld gebaut) und OHNE
umschließendes <html>/<body>.`;
}

async function callClaude(prompt) {
  const res = await fetch("https://api.anthropic.com/v1/messages", {
    method: "POST",
    headers: {
      "Content-Type": "application/json",
      "x-api-key": API_KEY,
      "anthropic-version": "2023-06-01",
    },
    body: JSON.stringify({
      model: MODEL,
      max_tokens: 4000,
      messages: [{ role: "user", content: prompt }],
    }),
  });

  if (!res.ok) {
    const errText = await res.text();
    throw new Error(`API-Fehler (${res.status}): ${errText}`);
  }

  const data = await res.json();
  const text = data.content.map((b) => b.text || "").join("\n");
  const cleaned = text.replace(/```json|```/g, "").trim();
  return JSON.parse(cleaned);
}

function buildFaqHtml(faq) {
  return faq
    .map(
      (item) => `
    <div class="faq-item">
      <h3>${escapeHtml(item.frage)}</h3>
      <p>${escapeHtml(item.antwort)}</p>
    </div>`
    )
    .join("\n");
}

function buildFaqSchema(faq) {
  return JSON.stringify(
    {
      "@context": "https://schema.org",
      "@type": "FAQPage",
      mainEntity: faq.map((item) => ({
        "@type": "Question",
        name: item.frage,
        acceptedAnswer: {
          "@type": "Answer",
          text: item.antwort,
        },
      })),
    },
    null,
    2
  );
}

function escapeHtml(str) {
  return String(str)
    .replace(/&/g, "&amp;")
    .replace(/</g, "&lt;")
    .replace(/>/g, "&gt;")
    .replace(/"/g, "&quot;");
}

function buildPage(topic, article) {
  const faqHtml = buildFaqHtml(article.faq);
  const faqSchema = buildFaqSchema(article.faq);

  return `<!DOCTYPE html>
<html lang="de">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>${escapeHtml(article.meta_title)}</title>
  <meta name="description" content="${escapeHtml(article.meta_description)}">
  <link rel="canonical" href="${SITE_URL}/${topic.slug}.html">

  <!-- Open Graph -->
  <meta property="og:title" content="${escapeHtml(article.meta_title)}">
  <meta property="og:description" content="${escapeHtml(article.meta_description)}">
  <meta property="og:type" content="article">
  <meta property="og:url" content="${SITE_URL}/${topic.slug}.html">

  <!-- Article Schema -->
  <script type="application/ld+json">
  {
    "@context": "https://schema.org",
    "@type": "Article",
    "headline": ${JSON.stringify(article.h1)},
    "description": ${JSON.stringify(article.meta_description)},
    "publisher": {
      "@type": "Organization",
      "name": ${JSON.stringify(SITE_NAME)}
    }
  }
  </script>

  <!-- FAQ Schema (wichtig für GEO/Featured Snippets) -->
  <script type="application/ld+json">
  ${faqSchema}
  </script>
</head>
<body>
  <article>
    <h1>${escapeHtml(article.h1)}</h1>

    ${article.body_html}

    <section class="faq" aria-label="Häufig gestellte Fragen">
      <h2>Häufig gestellte Fragen</h2>
      ${faqHtml}
    </section>

    <aside class="cta">
      <p>${CTA_TEXT}</p>
    </aside>
  </article>

  <!--
    REDAKTIONELLER HINWEIS (nicht für Live-Seite, bitte vor Veröffentlichung entfernen):
    Vorschlag Social-Media-Titel: ${article.social_media_titel || "-"}

    Beispiel-Prompts, für die dieser Artikel als KI-Quelle infrage kommt:
    ${(article.beispiel_prompts || []).join(" | ")}

    Vor Veröffentlichung prüfen: keine unbelegten Heilsversprechen,
    ggf. Praxisbeispiele nochmal auf Anonymität checken.
  -->
</body>
</html>
`;
}

async function main() {
  const args = process.argv.slice(2);
  const slugFilter = args.includes("--slug")
    ? args[args.indexOf("--slug") + 1]
    : null;

  const topics = JSON.parse(fs.readFileSync(TOPICS_FILE, "utf-8"));
  const selected = slugFilter
    ? topics.filter((t) => t.slug === slugFilter)
    : topics;

  if (selected.length === 0) {
    console.error(`Kein Thema mit slug "${slugFilter}" gefunden.`);
    process.exit(1);
  }

  if (!fs.existsSync(OUTPUT_DIR)) {
    fs.mkdirSync(OUTPUT_DIR, { recursive: true });
  }

  for (const topic of selected) {
    console.log(`Generiere: ${topic.thema} ...`);
    try {
      const prompt = buildPrompt(topic);
      const article = await callClaude(prompt);
      const html = buildPage(topic, article);
      const outPath = path.join(OUTPUT_DIR, `${topic.slug}.html`);
      fs.writeFileSync(outPath, html, "utf-8");
      console.log(`  -> gespeichert: ${outPath}`);
    } catch (err) {
      console.error(`  Fehler bei "${topic.slug}":`, err.message);
    }
  }

  console.log("\nFertig. WICHTIG: Alle Artikel im ./output-coaching-Ordner sind ENTWÜRFE.");
  console.log("Vor Veröffentlichung: SITE_NAME, SITE_URL und CTA_TEXT (Link zum Erstgespräch)");
  console.log("im Skript anpassen, Design/Layout einbauen, Inhalte gegenlesen.");
}

main();
